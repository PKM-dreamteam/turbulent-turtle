
#include "stdafx.h"

extern "C" {
#include "libswscale/swscale.h"
#include "libavcodec/avcodec.h"
#include "libavformat/avformat.h"
	//#include "libavutil/common.h"
	//#include "libavutil/fifo.h"
	//#include "libavutil/opt.h"
}
#include <opencv2/imgproc/imgproc.hpp>
#include <opencv2/highgui/highgui.hpp>

#include "opencv2/core.hpp"
//#include <opencv2/core/utility.hpp>
#include "opencv2/video/background_segm.hpp"
//#include "opencv2/videoio.hpp"
#include "opencv2/video/tracking.hpp"

#define _CRT_SECURE_NO_DEPRECATE
#include <stdio.h>
//#include <istream>
//#include <memory>


// compatibility with newer API
#if LIBAVCODEC_VERSION_INT < AV_VERSION_INT(55,28,1)
#define av_frame_alloc avcodec_alloc_frame
#define av_frame_free avcodec_free_frame
#endif

using namespace cv;
using namespace std;

class PKMVision01
{
public:
	PKMVision01();
	PKMVision01(int flag);
	~PKMVision01();

	int recView; // record view (set in params)

	// ALL IMG
	Mat imgRoi, imgRoiMask;
	Mat gimg0, gimg, fgmask, fgimg, bgimg; //gmm
	Mat flow, prevGray; // optFlow
	float rescale = 0.7;
	int startDelay; // delay processing X frames (some algorithms may need it)

	// GMM & PROCESS
	BackgroundSubtractorMOG2 bg_model;
	bool update_bg_model; // model update flag
	void gmm_init(); // init gmm variables
	void gmm(Mat* frame, bool smooth); // object detection algorithm
	void calcWhiteArea(Mat* orgFrame); // calculate mean RGB for a given area
	Rect whiteArea; // area for calcWhiteArea
	Scalar meanVal; // output RGB of calcWhiteArea
	bool runCanny; // flag to run Canny Edge Detection
	
	// OPTICAL FLOW
	bool opticalFlow_isInit;
	void opticalFlow(Mat* img);
	const int MAX_COUNT = 500; // max number of characteristics points
	bool needToInit;
	int resetPointsAfter; // reset optical flow after X frames
	int optFlowCounter; // frame counter
	int opticalType; // optical flow type (flow vectors, track points)
	vector<Point2f> points[2]; // characteristics points
	

	// MOUSE CALLBACK
	static void mouseHandler(int event, int x, int y, int flags, void* params);
	struct MouseParams{
		Point mouseXY;
		struct rectType{
			Rect selRect;
			int selType;
		} rectType;
		int flag;
	} mParams;
	
	// ROI
	void areasObjDetect();
	void setMultiROI(Mat* img);
	void setCheckAreas(Mat* img);
	void drawAreas(Mat* img, bool insideRoi);
	void saveROI();
	bool setROImask();
	Mat resizeToROImask(Mat* img0);
	vector<Rect> rectROI;
	struct RectBool{
		vector<Rect> area;
		vector<bool> isObject;
	} checkAreas;
	
	//vector<Rect> updatedROI;
	bool pointSet;
	bool paramsUpdated;
	bool openWindowToDraw, openRoiWindow, openForegroundWindow, setMask;
	int openOpticalFlowWindowAndType;

	// CONFIG & PARAMS
	bool loadParams(const string &filenameParam);
	bool saveParams(const string &filenameParam);
	bool paramsLoaded;
	int Xmin, Xmax, Ymin, Ymax;


};